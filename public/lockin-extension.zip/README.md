# Lock-In Extension
Unpack and load as unpacked extension in chrome://extensions
